#python program that adds 2 numbers and outputs the results


num1 = int(input("Enter First Number: "))
num2 = int(input("Enter Second Number: "))
print(num1 + num2)